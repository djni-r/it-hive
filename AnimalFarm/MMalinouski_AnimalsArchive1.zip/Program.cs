﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalFarm
{
    class Program
    {
        static void Main(string[] args)
        {
            // init new farm to work with
            AnimalFarm farm = new AnimalFarm();
            
            // add new dogs and cats from file
            User user1 = new User();
            user1.AddDogsFromFile(5, farm);
            user1.AddCatsFromFile(7, farm);

            Console.WriteLine("\nSearch for Kitty\n");
            farm.Search("Kitty");
            Console.WriteLine("\nSearch for Sphinx\n");
            farm.Search("Sphinx");
            
            Console.WriteLine("\nSearch for dogs:\n");
            farm.Search(typeof(Dog));

            Console.WriteLine("\nRemoving Sir");
            farm.Remove("Sir");
            
            // init new dog to add
            Dog newDog = new Dog("Jabber", 6, 'm');
            Console.WriteLine("Adding Jabber");
            farm.Add(newDog);

            // init new dog to update 
            Dog Hero = new Dog("Hero", 7, 'm');
            Console.WriteLine("Updating Hero");
            farm.Update(Hero);
            
            Console.WriteLine("\nAll animals:\n");
            farm.DisplayAll();

        }
    }
}
